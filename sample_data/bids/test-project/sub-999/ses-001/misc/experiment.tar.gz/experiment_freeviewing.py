"""
This script will contain the any experiment files (scripts, config files etc) specific to the EEG study.
This experiment folder can also contain subfolders for different tasks within the experiment and everything
you want to be copied as miscellaneous files as a part of our bigger dataset. This can be `.py`, `.sh`, `.json`,
`.osexp`, etc

For this sample, I just added a dummy script file to show how it can be done.
"""

print("This is a dummy experiment print code. You can replace it with your actual experiment code.")